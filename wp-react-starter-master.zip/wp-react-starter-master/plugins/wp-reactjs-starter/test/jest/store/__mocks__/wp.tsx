/* eslint-disable import/no-default-export */
export default {};
