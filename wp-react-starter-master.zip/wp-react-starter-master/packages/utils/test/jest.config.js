// Unfortunately the jest config can not be placed directly to package.json
// because then it does not support inheritance.

const base = require("../../../common/jest.base");

module.exports = base;
