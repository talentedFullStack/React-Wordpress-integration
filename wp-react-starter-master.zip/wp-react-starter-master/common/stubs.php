<?php
namespace {
    // Put your global namespaces here.
    // Learn more about it here: https://www.php.net/manual/en/language.namespaces.definitionmultiple.php
}
