# create-wp-react-app folder

This folder is required and should be committed to your git repository. It is used for further cli commands like create-wp-react-app create-plugin.
