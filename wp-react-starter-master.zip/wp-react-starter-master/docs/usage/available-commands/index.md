# Available commands

`wp-react-starter` comes with many commands (implemented as NPM scripts), which simplifies how you can control and use all the functions this boilerplate provides.

Here is a complete list of all available commands with a short description, separated into commands for the root project (applies to the compleat monorepo) and single plugins.

{% page-ref page="root.md" %}

{% page-ref page="plugin.md" %}

{% page-ref page="package.md" %}
